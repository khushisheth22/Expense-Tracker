// utils.js
function formatCurrency(value) {
  const opts = { 
    style: 'currency', 
    currency: 'INR', 
    minimumFractionDigits: 2, 
    maximumFractionDigits: 2 
  };
  const abs = Math.abs(Number(value) || 0);
  const formatted = abs.toLocaleString('en-IN', opts);
  return (Number(value) < 0 ? '-' : '') + formatted;
}

function getTransactions() {
  return JSON.parse(localStorage.getItem('expenseTracker_v1')) || [];
}
function saveTransactions(data) {
  localStorage.setItem('expenseTracker_v1', JSON.stringify(data));
}
