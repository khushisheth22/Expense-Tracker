// script.js
// Dashboard balance render
function renderBalance() {
  const transactions = getTransactions();
  const income = transactions.filter(t => t.type === 'income')
    .reduce((sum, t) => sum + Number(t.amount), 0);
  const expense = transactions.filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + Number(t.amount), 0);
  const balance = income - expense;

  document.getElementById('money-plus').innerText = formatCurrency(income);
  document.getElementById('money-minus').innerText = formatCurrency(expense);
  document.getElementById('balance').innerText = formatCurrency(balance);
}

// Add page logic
function initAddPage() {
  const form = document.getElementById('transaction-form');
  const nameInput = document.getElementById('transaction-name');
  const amountInput = document.getElementById('transaction-amount');
  const typeSelect = document.getElementById('transaction-type');
  const errorEl = document.getElementById('form-error');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = nameInput.value.trim();
    const amount = parseFloat(amountInput.value);
    const type = typeSelect.value;

    if (!name || isNaN(amount) || amount === 0) {
      errorEl.innerText = "Please enter valid details.";
      return;
    }

    const transactions = getTransactions();
    transactions.push({
      id: Date.now(),
      name,
      amount: Math.abs(amount),
      type,
      createdAt: new Date().toISOString()
    });
    saveTransactions(transactions);

    form.reset();
    errorEl.innerText = "✅ Transaction added!";
    setTimeout(() => errorEl.innerText = "", 3000);
  });
}

// History page logic
function renderHistory() {
  const listEl = document.getElementById('transaction-list');
  const transactions = getTransactions();

  listEl.innerHTML = '';

  if (!transactions.length) {
    listEl.innerHTML = "<p>No transactions yet.</p>";
    return;
  }

  // Group transactions by YYYY-MM
  const groups = {};
  transactions.forEach(t => {
    const d = new Date(t.createdAt);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    if (!groups[key]) groups[key] = [];
    groups[key].push(t);
  });

  // Sort groups (latest first)
  const sortedKeys = Object.keys(groups).sort((a, b) => b.localeCompare(a));

  sortedKeys.forEach(key => {
    const [year, month] = key.split('-');
    const monthName = new Date(year, month - 1).toLocaleString('en-IN', { month: 'long', year: 'numeric' });

    // Month heading
    const heading = document.createElement('h3');
    heading.textContent = monthName;
    listEl.appendChild(heading);

    // List for that month
    const ul = document.createElement('ul');
    ul.className = "month-list";

    groups[key].forEach(t => {
      const li = document.createElement('li');
      li.textContent = `${t.name} - ${t.type} - ${formatCurrency(t.amount)} (${new Date(t.createdAt).toLocaleDateString()})`;
      ul.appendChild(li);
    });

    listEl.appendChild(ul);
  });

  // Buttons
  document.getElementById('clear-btn').addEventListener('click', () => {
    if (confirm("Clear all transactions?")) {
      saveTransactions([]);
      renderHistory();
    }
  });

  document.getElementById('export-csv').addEventListener('click', () => {
    if (!transactions.length) return alert("No data to export!");
    const header = "id,name,type,amount,createdAt\n";
    const rows = transactions.map(t => `${t.id},"${t.name}",${t.type},${t.amount},${t.createdAt}`).join("\n");
    const blob = new Blob([header + rows], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "transactions.csv";
    a.click();
    URL.revokeObjectURL(url);
  });
}

